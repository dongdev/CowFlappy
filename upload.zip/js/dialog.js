function endGame() {
}
function leaderBoard() {
}
function tutorial() {
}