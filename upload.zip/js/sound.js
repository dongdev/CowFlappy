function canPlay() {
    //return dgame.playSound;
    return true;
}
function soundBg() {
    if (!canPlay())
        return;
    var sound = dgame.add.audio('bg', 1, true);
    sound.allowMultiple = true;
    sound.loop = true;
    sound.play("", 0, 1, true);
    dgame.soundBg = sound;
}
function soundCoin() {
    if (!canPlay())
        return;
    if (dgame.soundCoin == null) {
        var sound = dgame.add.audio('coin');
        sound.play();
        dgame.soundCoin = sound;
    }
    else {
        dgame.soundCoin.play();
    }

}
function soundJump() {
    if (!canPlay())
        return;
    if (dgame.soundJump == null) {
        var sound = dgame.add.audio('flap');
        sound.play();
        dgame.soundJump = sound;
    }
    else {
        dgame.soundJump.play();
    }
}
function soundFall() {
    if (!canPlay())
        return;
    if (dgame.soundFall == null) {
        var sound = dgame.add.audio('crash');
        sound.play();
        dgame.soundFall = sound;
    }
    else {
        dgame.soundFall.play();
    }
}
function mute(mute) {
    dgame.sound.mute = mute;
}